# GIS4 - Interpolation

Status: Done
Topics: continuous surface, cover, depth, elevation, interpolation, root-mean square, xy coordinate systems

[GIS4_Interpolation_ArcGIS_Pro_2025.pdf](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/GIS4_Interpolation_ArcGIS_Pro_2025.pdf)

- [x]  Thiessen
- [x]  Global interpolation
- [x]  local interpolation
- [x]  inverse distance
- [x]  Interpolation w/ Kringing
- [x]  3D
- [x]  Part 1 Questions
- [ ]  Part 2
    - [x]  Load data
    - [ ]  Do calculations
    - [ ]  Report results
- [ ]  Copy text to ntoebook

# Before you start

Process all interpolation methods listed below, and, for each, write down minimum and maximum predicted values and the Root-mean-Square value (RMS) (except for the Thiessen polygons)

Note: the layers resulting from the interpolation processes are temporary map layers. To make them permanent (i.e. keep them as rasters once you close your project) you have to save them to disk: right-click on layer → Export Layer → To Rasters (use “.tif” Extension to save it as TIFF, e.g. “Kriging.tif”). Note that you cannot save .tif directly in a File Geo database(.gdb), so make sure your path in the field “Output raster” doesn’t contain any “.gdb”. Use output cell size= 100

| **method** | **min** | **max** | **rms** |
| --- | --- | --- | --- |
| thiessen | 1074 | 2468 | - |
| global interpolation (2nd) | 1132,3266 | 2280,4552 | 237,61322446599 |
| global interpolation (6th) | 797,9881 | 2336,9724 | 211,912982681134 |
| local interpolation (2nd) | 1138,0978 | 2321,5493 | 172,876644325283 |
| local interpolation (6th) | 868,7464 | 2349,9424 | 185,091443416614 |
| inverse distance weighting | 1248,1290 | 2420,4121 | 162,83 |
| interpolation w/ kringing | 1232,4086 | 2808,8953 | 174,5801 |

## Methods

### Thiessen polygons

1) Make Thiessen polygons from the dataset: Toolboxes → Analysis Tools → Proximity → Create Thiessen Polygons

2) Set “Input Features” as “Elevation_Jotun.shp”, Output Feature Class: “Thiessen_hoyde.shp”, Output Fields: “All fields”. Change “Color Ramp” if you want to.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%201.png)

3) Define color for the shapefile by selecting Appearance Symbology Graduated colors. Field: HOEYDE (elevation). Method: Quantile. Choose any color scheme and number of classes.

4) The use of Thiessen polygons is a way to relate point data to space. What kind of geographical observations listed here is meaningful to represent with Thiessen polygons?

o 1) Rainfall, 2) Meteorological stations, 3) Temperature

→ Rainfall and temperature make sense to represent with Thiessen polygons, since these point data can be spatially interpolated, generalized to all of the area closest to each data point. Meteorological stations on their own are just points, and don’t represent any spatial information. However, if you wanted to say *area covered by meteorological stations,* then yes, Thiessen plots could also be a good way of representing these data too. 

### Global interpolation of 2nd and 6th order

1) Analysis → Geostatistical Wizard . Step 1: Method = Global Polynomial interpolation, Input data = Elevation_Jotun, Data Field = HOEYDE → Next

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%202.png)

2) Step 2: Change the order of polynomial. Observe how the colours change. What do they mean? Why do we get this pattern? Choose order 2 → Next

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%203.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%204.png)

The order is the number of terms (and thus exponents) the polynomial used to describe the plane has. The higher the order, the more variables, and further the more degrees of freedom the polynomial has. If the polynomial's order matches the number of data points (**order N with N points**), the polynomial will exactly intersect with every single point, thus “perfectly” representing the data, most likely by overfitting, making a polynomial unrealistic for general use. The ideal order of polynomial is then likely much lower than *N*, and generalizes well when calculated on random subsamples of the same data (i.e. roughly the same interpolation layer is generated).

3) Step 3: What do the values and the chart mean? Write down the minimum and maximum predicted values from the Table and the Root-Mean-Square (RMS) from the Summary. 

→ Finish and export to raster (right-click → Export Layer → To Rasters), and repeat the same for a 6th order polynomial

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%205.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%206.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%207.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%208.png)

**6th:**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%209.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2010.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2011.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2012.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2013.png)

| **Count** | 131 |
| --- | --- |
| **Mean** | -5,03854979361153 |
| **Root-Mean-Square** | 211,912982681134 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2014.png)

What do the values and the chart mean? 

→ The “predicted” surface is the simplified representation of the surface based on the measurements. Predicted height is slightly off of the true measurement because of this generalization, giving the error. Ideal surface representations are those that minimize the error between prediction and true measure across all points. RMS is one metric in which to calculate this error. We see that as the order of polynomial increase, our RMS will decrease. As mentioned before, we need to find a good trade off between error mitigation (bias) and generalization (variability). 

### Local interpolation of 2nd and 6th order

1) Analysis → Geostatistical Wizard. Step 1: Method = Local Polynomial Interpolation, Input data = Elevation_Jotun, Data Field = HOEYDE → Next

2) Step 2: It is possible to choose the size of the neighborhood of the interpolation (Exploratory Trend Surface Analysis) from 100 % local (Value=100, small neighborhood) to 100% global (Value=0, the whole area is included in the neighborhood). Study the effect of changing these settings. Set the Order of Polynomial to 2. Write down the number of percentage in the “Exploratory Trend Surface Analysis”

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2015.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2016.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2017.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2018.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2019.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2020.png)

3) Step 3: Write down the minimum and maximum predicted values from the table and the RMS-value. → Finish and export to raster, and repeat the same for a 6th order polynomial.

2nd:

| **Count** | 131 |
| --- | --- |
| **Mean** | 6,29046917656899 |
| **Root-Mean-Square** | 172,876644325283 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2021.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2022.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2023.png)

**6th:**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2024.png)

| **Count** | 131 |
| --- | --- |
| **Mean** | 3,25790303923317 |
| **Root-Mean-Square** | 185,091443416614 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2025.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2026.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2027.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2028.png)

### Inverse distance weighting

1) Analysis → Geostatistical Wizard .

2) Choose Inverse distance weighting, and datasets as before. 

3) Step 2: Try out different numbers of neighbors (maximum/minimum), choosing a combination that produces a good result and write down the number of neighbors.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2029.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2030.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2031.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2032.png)

Clicking around, you see that the elevation at any given point is based on the neighbors and their weighting. If you click directly on a point, that “neighbor” is going to have the highest weight, and the rest very low values. Focusing on more baren areas shows that the closest neighbors influence quite a lot, and the further out a neighbor lies, the lower weight it has to contribute to the predicted height. 

Given there are often not more that 10-15 really meaningful neighbors around any given point in our data, these seem like good values to keep as the min and max, respectively. 

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2033.png)

| **Count** | 131 |
| --- | --- |
| **Mean** | 23,25 |
| **Root-Mean-Square** | 175,80 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2034.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2035.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2036.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2037.png)

| **Count** | 131 |
| --- | --- |
| **Mean** | 24,91 |
| **Root-Mean-Square** | 169,66 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2038.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2039.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2040.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2041.png)

| **Count** | 131 |
| --- | --- |
| **Mean** | 23,89 |
| **Root-Mean-Square** | 162,83 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2042.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2043.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2044.png)

Going for min 3 max 7. 

4) Step 3: Study the prediction map and the errors and write down the minimum and maximum predicted values from the table and the RMS-value. Finish the process and export to raster.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2045.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2046.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2047.png)

### Interpolation w/ Kringing

1) Analysis → Geostatistical Wizard → Kriging/CoKriging 

2) Step 1: Datasets and attributes as before. Input Dataset 2 should be <none>. → Next

3) Step 2: Choose Ordinary kriging (first on the list) and Prediction (Later you can also try other types of kriging to explore the differences)

a) Try first without removing any trend (Order of **trend removal = None**)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2048.png)

---

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2049.png)

A trend will be visible as an increasing estimation line across the semivariogram. Ideally, we want this estimation line to flatten out, in others words to be a **sill**. 

This plot with no trend removal shows a trend, so we need to try applying a trend removal. 

b) Try to find out if there is a trend by studying the semivariogram and semivariogram map. If there is a trend, go back to step 2 and try a **first order removal of trend**. 

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2050.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2051.png)

---

The semivariogram is looking flatter, but still not quite to where it can be called a sill yet. 

Let’s try one more order increase.

### More kriging

If there is still a trend, try a **second order trend removal**. Write down the nugget, range and sill sizes for the different settings you use (given in step 4 of 6). These can be used to explain the result.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2052.png)

---

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2053.png)

Since we are at it, let’s also try a **3rd order removal**, to really emphasize the sill. 

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2054.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2055.png)

Now the sill in the semivariogram is very obvious. So much more so than the 2nd order, that I think its best to keep the 3rd order. Let’s move on to step 4. 

4) The next window (step 5 of 6) shows how many neighbors the interpolation includes.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2056.png)

I chose a max number of neighbors to 6, and a minimum of 2, using the 4 sectors. This means that each quadrant (w/ 45° offset) each has to weight a minimum of 2 neighbors, and a max neighbor count of 6. There is no where on our plots where more than 6 exists. 

5) The last window shows the prediction map and errors.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2057.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2058.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2059.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2060.png)

| **Count** | 131 |
| --- | --- |
| **Mean** | 22,5856 |
| **RMS** | 174,5801 |
| **Mean Std** | 0,13769 |
| **RMS Std** | 1,44195 |
| **Avg Std Error** | 117,1273 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2061.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2062.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2063.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2064.png)

### Kriging w/ Model Optimization

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2065.png)

| **Count** | 131 |
| --- | --- |
| **Mean** | 11,2614387168977 |
| **Root-Mean-Square** | 161,153483031683 |
| **Mean Standardized** | 0,0606869944133808 |
| **Root-Mean-Square Standardized** | 1,25950881809403 |
| **Average Standard Error** | 115,763979543482 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2066.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2067.png)

### 3D

It is possible to look at the interpolations in 3D together with the correct elevation points. We want to compare these interpolation methods:

1) Global interpolation (2nd polynomial and 6th polynomial)

2) Local interpolation (2nd polynomial)

3) Inverse distance weighting (IDW) 

4) Kriging

Go to Insert New Map New Local Scene. Local Scene allows displaying data in 3D.

1) Add “Elevation_Jotun.shp”. It will be added as “2D Layers”. We have to add more information so it will be shown as 3D layer. There are two ways:

 a) Alternative 1: Click on the layer name. Go to Appearance, Click on Type in the Extrusion group. Choose “Absolute Height”. Next to it, you should choose Field: “HOEYDE”.

 b) Alternative 2: Right-click on the layer name. Choose “Properties”, and go to “Elevation”. Modify the parameters as shown below. Move the layer from “2D Layers” to “3D Layers”

2) Right-click on “Elevation Surfaces” in the “Contents” pane. Choose “Create surfaces from sources”. Find a raster with interpolated data. This adds merely elevation data without any raster layer. Therefore, now you can add the same raster again using “Add Data” . After you add the raster, it will not float in 3D yet. Right-click on the raster name. Choose “Properties”and “Elevation”, change “Features are”: “On custom elevation surface”. Adjust custom surface

3) Do this for all raster interpolations listed above.

NOTE! You can exaggerate the values so it is easier to visually interpret the results. If you chose the Alternative 1: Click on the “Elevation_Jotun.shp” ribbon with “Appearance”

Next to “Field” choose “Extrusion expression” = “$feature.HOEYDE*5” for Arcade or “[HOEYDE]*5” for VBScript.

If you chose the Alternative 2: Right-click on “Elevation_Jotun.shp”. Choose “Properties”, and go to “Elevation”. Modify “Vertical Exaggeration” to e.g. 5,00.

Only the points are exaggerated now. You can also exaggerate each interpolated raster by clicking on the group name in the “Contents” pane under “Elevation Surfaces”, i.e. the layer above .tif file:

6A ribbon with “Appearance” should show, there you can choose “Vertical exaggeration”. Choose 5,00 if you chose 5 for the points.

I set the four layers we are observing to different heights for better distinguishability between them:

| layer | vertical exaggeration |
| --- | --- |
| Kriging | 8 |
| Inverse Distance Weighting | 6 |
| Global Polynomial Interpolation (6th order) | 4 |
| Global Polynomial Interpolation (2nd order) | 2 |

This let me adjust the elevation points in `Elevation_Jotun.shp` to each vertical exaggeration and check whether the layer is an approximation or exact match. 

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2068.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2069.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2070.png)

# Part 1

### I

### Which interpolation methods that is local/global and exact/not exact?

Both Kriging and Inverse Distance Weighting seems to be very localized, while the Global Polynomial Interpolation at both 2nd and 6th order is a smoothed global approximation. 

By varying the vertical exaggeration of the elevation points, it looks that both IDW and Kriging are exact match layers, or very close to it. For a layer to be an exact match it must exactly intersect the true measured elevation for every point that exists in our data. The global polynomial interpolations are obviously smoothed approximations of the elevation points, as they do not capture all the variance of the elevation points. 

A peculiar mismatch between the observed data and my intuition here is that the Kriging and IDW layers still have errors greater than zero. This is read from their values of RMS. If these layers were true exact matches, I would have expected this value to be 0. Since the RMS for these layers are relatively closer to the RMS values of the global interpolation methods than they are zero, we should conclude that these layers are also only approximations, not exact matches. 

Upon further research, both IDW and Kriging can produce exact match results. This happens when kriging layers have a nugget of 0, and when IDW uses a high enough number of neighbors. The values I chose for producing each of these layers instead gave smoothed approximations of the true elevation profile, making them likely more generalized. Such configurations can be useful when we known our elevation data has some level of uncertainty greater than zero. 

### Lists some advantages and disadvantages for each interpolation method.

**General**

During this interpolation analysis, we’ve found that the more information used to build an interpolation raster, the better representation of the elevation profile you will achieve. The downside to these better approximations is computation complexity. Increased complexity can open for a range of difficulties downstream in an analysis process, from explainability to slow compute times. 

Global polynomials much more efficient to store and compute, since they are represented by a limited amount of variables. The raster layers produced here are smooth, capturing only the most prominent changes in the environment being observed. The obvious downside here is the greater amount of error introduced to the analysis. If a high level of certainty is needed on a more granular level, for example in construction planning and engineering problems, more localized methods should be prioritized. 

**Kriging**

Using the semivariance between points, kriging finds the optimal relation between how much neighboring points in the input data should influence each other. This not only makes kriging the most statistically optimal interpolation method, but also provides a variance surface, which represents each cell’s corresponding certainty. Localized predictions with certainty estimations make kriging a great method for use-cases that requires fine-grained resolution with limited or sparse data. 

Due to being an abstract statistic on the data, interpretability of kriging can be more cumbersome than other simpler models. To understand the trends the model is picking up on from the data, an analyst needs to be able to interpret a semivariogram, which is not always directly intuitive. Kriging’s added complexity of fitting a variogram model and solving a system of equations for each prediction makes calculating these interpolations slower than other methods, especially when interpolating large data sets. These equations assume the input data has some innate statistical predictability, which might not always be the case, for example with very noisy data, highly irregular sampling patterns, or human-influenced landscapes.

**IDW**

Inverse distance weighting can be a quite simple exact approach to elevation mapping, requiring only a search radius and influence coefficient. Synonymous to a circus tent with the internal poles representing the measured input elevations, these models are often highly intuitive. Cells of an inverse distance weighted raster are calculated from, and influenced by, their closeness to their neighbors. This preserves the local variation captured by the measurements, and is typically considered robust, even over sparsely populated regions in an otherwise very clustered dataset. 

A flaw of highly localized models is that they tend to focus only on a point immediate neighborhood, and thus fail to pick up on any global trends, making it less adaptable to a complex terrain. This can lead to heavily biased representations if sampling is not fairly distributed. Also, proper tuning is important when using IDW, since the power parameter and search radius can be very sensitive to overfitting. 

**Global & Local Polynomial**s

Being the simplest of our interpolation models global and local polynomials are fast and efficient approximations, making them ideal for situations with densely populated data that needs to be compressed or simplified. Global polynomials are more likely to focus on larger trends across the data, while local polynomials enable more granular representations. Splines are an example of local polynomials that are relatively robust against clustered data, as long as sampling can be considered fair, for example if sparse measurements are due to smoothed terrain with little variance. 

Global polynomials are usually coarse representations, making them typically very underfit compared to the other interpolation methods we’ve observed. Local polynomials are prone to overfitting and can also be quite sensitive to parameter tuning, similar to IDW. In areas of complex terrain, they may oscillate or produce artifacts that don’t reflect realistic surface features.

### Which method seems to give the best result?

| **method** | **min** | **max** | **rms** |
| --- | --- | --- | --- |
| thiessen | 1074 | 2468 | - |
| global interpolation (2nd) | 1132,3266 | 2280,4552 | 237,61322446599 |
| global interpolation (6th) | 797,9881 | 2336,9724 | 211,912982681134 |
| local interpolation (2nd) | 1138,0978 | 2321,5493 | 172,876644325283 |
| local interpolation (6th) | 868,7464 | 2349,9424 | 185,091443416614 |
| inverse distance weighting | 1248,1290 | 2420,4121 | 162,83 |
| interpolation w/ kringing | 1232,4086 | 2808,8953 | 174,5801 |
| true | 1074 | 2468 | 0 |

Table 1 compares the observed interpolation methods by three metrics calculated from their predictions: the minimum, maximum, and root-mean-square (RMS) errors. In my analysis, each interpolation method was tuned based on what seemed to be a good result. Tuning was likely suboptimal, so the best-performing methods I present below may differ from those found by others running the same experiment.

Considering RMS as the most important loss metric to optimize for, we would conclude that the IDW configuration found was the best approximation to the input data we are analyzing. However, it is important to consider the generalizability of this configuration, given that IDW can be sensitive to overfitting. If we were to evaluate the IDW model against another set of measurements (another device, different points, etc), its RMS might actually be much higher than that of the some of the other models. 

Given what we’ve learned about kriging — that it is statistically grounded, spatially adaptive, its corresponding confidence surface — its relatively low RMS score suggests that it might actually be the better model for the observed area. Kriging takes into consideration both local neighborhoods and global variance. So even though it doesn’t have the absolute lowest RMS on these data for this analysis, it is likely still the best, generalized interpolator in this terrain. 

# Part 2

In the data set “monthly_thaw_snow.dbf”, both snow and thaw depth is sampled in a grid (regular sampling) every 10 meter (121 points) and the total size is 100x100m

### Importing point files

- Add the dataset to your project using “Add Data”
- In the Contents pane, right-click on the dataset and choose “Display XY Data” to add the point data as a layer.
- Load “month_thaw_snow.dbf”: Column XM is the X- and column XY is the Y-coordinates in all three files. In the Z Field you can choose between:
    - o SNOW200705 – Snow depth in May 2007
    - o THAW200705 to 200709 – Active layer thaw depth in May – September 2007

Note: The data we use in this part of the assignment do not have a spatial reference. The point is to get to know different interpolation techniques and analyse the results.

Interpolate the data (same procedure as in part 1), and make analyses so that you can answer the questions below. Use the raster calculator (View  Geoprocessing  Toolboxes  Spatial Analyst Tools  Map Algebra  Raster Calculator) and excel to do the analysis. Remember to use the same interpolation algorithm every time you interpolate if you want to compare two rasters!

## Interpolation (correct)

| data | **method** | **rms** |
| --- | --- | --- |
| ***SNOW200705*** | ***kriging*** | ***3.2978*** |
| SNOW200705 | IDW | 3.6789 |
| SNOW200705 | global (1st) | 3.8067 |
| SNOW200705 | global (4th) | 3.6635 |
| ***THAW200705*** | ***kriging*** | ***7.6265*** |
| THAW200705 | IDW | 7.9546 |
| THAW200705 | global (4th) | 8.2112 |
| *THAW200709* | *kriging* | *5.3182* |
| THAW200709 | IDW | 5.4127 |
| THAW200709 | global (4th) | 5.4672 |

### SNOW200705

**Global Polynomial Interpolation (1st order)**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2071.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2072.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2073.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2074.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 1,54424502513752 |
| **Root-Mean-Square** | 3,80674136276101 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2075.png)

**Global Polynomial Interpolation (6th order)**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2076.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2077.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2078.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 1.28035646340592 |
| **Root-Mean-Square** | 3.6635 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2079.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2080.png)

**IDW** 

Power: 5, Max k: 5, min k: 2, sector: 4 offset→ RMS 3.6740

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2081.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2082.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2083.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2084.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 1.3553 |
| **Root-Mean-Square** | 3.6741 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2085.png)

**IDW (more general)**

Power 2: max: 3, min: 1, sector: 4 offset → RMS = 3.6789

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2086.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2087.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2088.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 1.5030 |
| **Root-Mean-Square** | 3.6789 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2089.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2090.png)

**Kriging**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2091.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2092.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2093.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2094.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 0.1199 |
| **RMS** | 3.2978 |
| **Avg Std Error** | 3.2628 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2095.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2096.png)

### THAW200709

**Global Polynomial Interpolation (4th)**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2097.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2098.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%2099.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20100.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 0,214619057782157 |
| **Root-Mean-Square** | 5,46717301937086 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20101.png)

**IDW** 

Power 2, max 3, min 1, sector: 4 offset → RMS = 5.4123

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20102.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20103.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20104.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 0,213593031122312 |
| **Root-Mean-Square** | 5,41226163325195 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20105.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20106.png)

**Kriging**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20107.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20108.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20109.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20110.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20111.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | -0.0456 |
| **RMS** | 5.3182 |
| **Avg Std Error** | 5.2153 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20112.png)

### THAW200705

**Global Polynomial Interpolation**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20113.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20114.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20115.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 1,37206052306573 |
| **Root-Mean-Square** | 8,21119198500437 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20116.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20117.png)

**IDW** 

Power 2, max 3, min 2, sector 4 offset → RMS = 7.9546

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20118.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20119.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20120.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20121.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | 1,39975724264194 |
| **Root-Mean-Square** | 7,95462868279656 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20122.png)

**Kriging**

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20123.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20124.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20125.png)

| **Count** | 121 |
| --- | --- |
| **Mean** | -0,3478 |
| **Root-Mean-Square** | 7,6265 |
| **Average Standard Error** | 7,8881 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20126.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20127.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20128.png)

### THAW200708

| **Count** | 121 |
| --- | --- |
| **Mean** | -0,0691 |
| **Root-Mean-Square** | 4,8672 |
| **Avg Std Error** | 4,9290 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20129.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20130.png)

### THAW200707

| **Count** | 121 |
| --- | --- |
| **Mean** | -0,1047 |
| **RMS** | 4,9031 |
| **ASE** | 4,8497 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20131.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20132.png)

### THAW200706

| **Count** | 121 |
| --- | --- |
| **Mean** | -0,2710 |
| **RMS** | 7,5513 |
| **ASE** | 6,9517 |

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20133.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20134.png)

[bad iteration of interpolation on snow melt data](https://www.notion.so/bad-iteration-of-interpolation-on-snow-melt-data-1d4019e059d18064834dce153a615912?pvs=21)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20135.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20136.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20137.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20138.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20139.png)

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20140.png)

## Questions

### Which interpolation method did you choose and why?

~~→ Global polynomials seem like the best generalized interpolator. Kriging was another good candidate, but due to its higher level of complexity, it was hard to find an optimal configuration that fit well with all of the layers observed (both snow and thaw). In this case, we’d prefer a generalizable model since the local variations seem minimal compared to the global trend.~~ 

→ Kriging seems like the best interpolator for these data. It consistently had the smallest error (RMS), was often more detailed than the global plots, and had more natural layer boundaries than IDW. 

### Is there a trend in mean thaw depth throughout summer of 2007? If so, why?

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20141.png)

**Figure X**: Box plots show the distribution of thaw data over the 5 months of measurements.
The wider the spread, the greater the variation in thaw data across the 11x11 grid.
The yellow line shows the median value at each month, while the blue dotted line shows the mean value.
The lower and upper limits of the box show the 25th (Q_1) and 75th (Q_3) percentiles of the data, respectively. The whiskers show the range of ±1.5 x IQR, where IQR=Q_3 - Q_1.
The circles dots outside the whiskers are the outliers in the data.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20142.png)

**Figure X**: A simplified display of the description data from the box plot. Here, only the mean, variance and ranges for each month are shown. As the summer progresses, the mean thaw depth increases, while the variance and range of the measurements decrease. The flattening of all the curves around August and September tells us the system is becoming more stable as the summer progresses. 

### Is there a relation between snow depth in May and the difference in active layer depth between May and September?

Do a regression analysis or visually interpret the result.

![image.png](GIS4%20-%20Interpolation%2019b019e059d180ddbce5ee1cbf22320b/image%20143.png)

Note:

1. For this analysis use raster calculator to subtract one raster from the other.

2. Create a random point dataset using “Create Random Points” (View  Geoprocessing  Toolboxes  Data Management Tools  Sampling  Create Random Points). Use one of the layers as “Constraining Feature Class” and “Number of points = 100”.

3. Use “Sample” (View  Geoprocessing  Toolboxes  Spatial AnalystTools  Extraction  Sample) on the interpolation result and extract values from the random points.

4. From this you get a table that you can import in excel and make a regression analysis.

## Report

Part 2 in this exercise is the basis for the lab report. Include introduction, methods and data, results, discussion and conclusion. Add also a flow chart of the process in part 2 on the relation between snow depth and active layer. Make a figure of the difference in active layer depth between May and September and the result from the regression analysis